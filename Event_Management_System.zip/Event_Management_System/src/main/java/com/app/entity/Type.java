package com.app.entity;

public enum Type {

		WEDDING,FESTIVAL,EXHIBITION,CHARITY
}
